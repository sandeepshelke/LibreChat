import { PassThrough } from 'stream';
import { posix as path } from 'path';
import { EventEmitter } from 'events';
import type { WriteFileOptions, MakeDirectoryOptions, Stats } from 'fs';
import type { ChildProcessWithoutNullStreams } from 'child_process';
import type { FileHandle } from 'fs/promises';
import type { WorkspaceFS, ReaddirEntry } from '@/tools/local/workspaceFS';
import type * as t from '@/types';
import {
  WorkspaceClientTimeoutError,
  isWorkspaceClientTimeoutError,
} from '@/tools/local/workspaceFS';
import {
  LOCAL_SPAWN_TIMEOUT_MS,
  validateBashCommand,
} from '@/tools/local/LocalExecutionEngine';

const DEFAULT_WORKSPACE_ROOT = '/workspace';
const DEFAULT_TIMEOUT_MS = 60000;
const DEFAULT_MAX_OUTPUT_CHARS = 200000;
const PROTECTED_TARGET_ARG_RE = /^(?:\/|~|\$\{?HOME\}?|\.)(?:\/?\.?\*|\/)?$/;
const DESTRUCTIVE_OP_IN_COMMAND_RE =
  /\b(?:rm\s+-[^\s]*[rf]|chmod\s+-R|chown\s+-R)\b/;

type SpawnResult = {
  stdout: string;
  stderr: string;
  exitCode: number | null;
  timedOut: boolean;
};

type RuntimeCommand = {
  fileName: string;
  source?: string;
  command: string;
};

type SandboxRuntimeContext = {
  sandbox: t.CloudflareSandboxRuntime;
  workspaceRoot: string;
  env?: Record<string, string | undefined>;
  timeoutMs: number;
  maxOutputChars: number;
  shell: string;
};

type ExecutionWorldCacheEntry = {
  world: t.ExecutionWorld;
  workspaceRoot: string;
  timeoutMs: number;
  sandbox: t.CloudflareSandboxExecutionConfig['sandbox'];
};

const executionWorldCache = new WeakMap<
  t.CloudflareSandboxExecutionConfig,
  ExecutionWorldCacheEntry
>();

type SandboxFactoryCacheEntry = {
  sandbox: () =>
    | t.CloudflareSandboxRuntime
    | Promise<t.CloudflareSandboxRuntime>;
  promise: Promise<t.CloudflareSandboxRuntime>;
};

const sandboxFactoryCache = new WeakMap<
  t.CloudflareSandboxExecutionConfig,
  SandboxFactoryCacheEntry
>();

function normalizeWorkspaceRoot(workspaceRoot: string): string {
  const normalized = path.normalize(workspaceRoot);
  return normalized === '/' ? normalized : normalized.replace(/\/+$/, '');
}

export function getCloudflareWorkspaceRoot(
  config?: t.CloudflareSandboxExecutionConfig
): string {
  return normalizeWorkspaceRoot(
    config?.workspaceRoot ?? DEFAULT_WORKSPACE_ROOT
  );
}

export async function resolveCloudflareSandbox(
  config: t.CloudflareSandboxExecutionConfig
): Promise<t.CloudflareSandboxRuntime> {
  const sandbox = config.sandbox;
  if (typeof sandbox !== 'function') {
    return sandbox;
  }
  const cached = sandboxFactoryCache.get(config);
  if (cached?.sandbox === sandbox) {
    return cached.promise;
  }
  const promise = Promise.resolve()
    .then(() => sandbox())
    .catch((error: unknown) => {
      if (sandboxFactoryCache.get(config)?.promise === promise) {
        sandboxFactoryCache.delete(config);
      }
      throw error;
    });
  sandboxFactoryCache.set(config, { sandbox, promise });
  return promise;
}

async function getRuntimeContext(
  config: t.CloudflareSandboxExecutionConfig
): Promise<SandboxRuntimeContext> {
  return {
    sandbox: await resolveCloudflareSandbox(config),
    workspaceRoot: getCloudflareWorkspaceRoot(config),
    env: config.env,
    timeoutMs: config.timeoutMs ?? DEFAULT_TIMEOUT_MS,
    maxOutputChars: config.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS,
    shell: config.shell ?? 'bash',
  };
}

function toSandboxPath(filePath: string, workspaceRoot: string): string {
  const raw = filePath === '' ? '.' : filePath;
  const root = normalizeWorkspaceRoot(workspaceRoot);
  const resolved = raw.startsWith('/')
    ? path.normalize(raw)
    : path.resolve(root, raw);
  if (root === '/') {
    return resolved;
  }
  if (resolved === root || resolved.startsWith(`${root}/`)) {
    return resolved;
  }
  throw new Error(
    `Path is outside the Cloudflare sandbox workspace: ${filePath}`
  );
}

function quote(value: string): string {
  if (value === '') {
    return '\'\'';
  }
  if (/^[A-Za-z0-9_/:=.,@%+-]+$/.test(value)) {
    return value;
  }
  return `'${value.replace(/'/g, '\'\\\'\'')}'`;
}

function withInSandboxTimeout(command: string, timeoutMs: number): string {
  const timeoutSeconds = Math.max(1, Math.ceil(timeoutMs / 1000));
  return `timeout -k 2s ${timeoutSeconds}s ${command}`;
}

function outerTimeoutMs(timeoutMs: number): number {
  return timeoutMs + 5000;
}

function isInSandboxTimeoutExit(exitCode: number | null): boolean {
  return exitCode === 124 || exitCode === 137;
}

/**
 * Client-side backstop timeout for a `sandbox.exec()` await: a few seconds beyond
 * the exec's own `timeout` option, so a stalled exec that never honors `timeout`
 * still can't outlast this.
 */
export function clientExecTimeoutMs(timeoutMs: number): number {
  return outerTimeoutMs(timeoutMs) + 5000;
}

/**
 * Client-side backstop timeout for a native-DO sandbox FILE-IO RPC
 * (`readFile`/`writeFile`/`listFiles`/`mkdir`/`deleteFile`). Unlike `exec()`
 * there is no in-sandbox `timeout(1)` layer for these to honor, so this is just a
 * few seconds of headroom over the configured tool timeout — enough that a normal
 * (even large, byte-capped) read completes, while a stalled/cold container can't
 * outlast it. See `withClientTimeout` for why the native DO RPC needs this.
 */
export function clientFsTimeoutMs(timeoutMs: number): number {
  return timeoutMs + 5000;
}

/**
 * Bound a `sandbox.exec()` await with a CLIENT-SIDE timeout.
 *
 * The native Cloudflare Sandbox Durable Object `exec()` is effectively
 * uncancellable from the host: `ExecOptions` has no `signal` (so
 * `supportsExecSignal` is false for the native transport), and its `timeout`
 * option is not reliably enforced when the container/RPC itself stalls — while
 * the in-sandbox `timeout(1)` wrapper only bounds a command that is actually
 * running. So a stalled exec (an unresponsive/cold container) otherwise hangs
 * until the host's run-level abort, burning the whole run budget on one tool
 * call. This race guarantees the host await settles within `timeoutMs`
 * regardless of the transport.
 *
 * On timeout the underlying `exec` promise may keep running in the DO (a
 * native-DO exec cannot be truly cancelled), so its late settlement is swallowed
 * to avoid an unhandled rejection.
 */
export async function withClientTimeout<T>(
  exec: Promise<T>,
  timeoutMs: number,
  label: string,
  options: {
    /**
     * Detach the backstop timer from the event loop. Use ONLY when something else
     * already settles the caller (e.g. the spawn path, where spawnLocalProcess's
     * own timer resolves the child). The awaited direct-exec paths must leave it
     * REF'd so the timeout is guaranteed to fire even if nothing else is pending.
     */
    unref?: boolean;
    /** Invoked when the client timeout fires — e.g. abort a signal-aware exec. */
    onTimeout?: () => void;
  } = {}
): Promise<T> {
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    return exec;
  }
  // Swallow a late rejection from the losing promise after the race settles.
  exec.catch(() => undefined);
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      exec,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => {
          // Reject FIRST so this client-timeout message reliably wins the race;
          // only then abort a signal-aware exec, whose resulting AbortError must
          // not surface to the caller instead of the timeout.
          reject(
            new WorkspaceClientTimeoutError(
              `${label} exceeded ${timeoutMs}ms client-side timeout (sandbox RPC did not return)`
            )
          );
          options.onTimeout?.();
        }, timeoutMs);
        if (options.unref === true) {
          (timer as { unref?: () => void } | undefined)?.unref?.();
        }
      }),
    ]);
  } finally {
    if (timer !== undefined) {
      clearTimeout(timer);
    }
  }
}

/**
 * Run `sandbox.exec()` bounded by a client-side timeout, and — for signal-aware
 * transports (e.g. the HTTP bridge, `supportsExecSignal === true`) — abort the
 * underlying exec when the timeout fires instead of merely abandoning it. The
 * native DO transport ignores `signal`, so it only gets the timeout. Leaves the
 * backstop timer ref'd (this is an awaited direct-exec path).
 */
export async function execWithClientTimeout(
  sandbox: t.CloudflareSandboxRuntime,
  command: string,
  options: t.CloudflareSandboxExecOptions,
  timeoutMs: number,
  label: string,
  runOptions: { unref?: boolean } = {}
): Promise<t.CloudflareSandboxExecResult> {
  const controller = new AbortController();
  const execOptions: t.CloudflareSandboxExecOptions = { ...options };
  const callerSignal = options.signal;
  let onCallerAbort: (() => void) | undefined;
  if (sandbox.supportsExecSignal === true) {
    // Compose the caller's signal (e.g. run/user cancellation) with our timeout
    // controller so EITHER source cancels the exec — don't clobber the caller's.
    if (callerSignal != null) {
      if (callerSignal.aborted) {
        controller.abort();
      } else {
        onCallerAbort = (): void => controller.abort();
        callerSignal.addEventListener('abort', onCallerAbort, { once: true });
      }
    }
    execOptions.signal = controller.signal;
  } else if ('signal' in execOptions) {
    // Native DO RPC cannot consume an AbortSignal (and would fail to clone it).
    // Strip any caller-provided one so the spread above can't reintroduce it.
    delete execOptions.signal;
  }
  try {
    return await withClientTimeout(
      sandbox.exec(command, execOptions),
      timeoutMs,
      label,
      {
        unref: runOptions.unref,
        onTimeout: () => controller.abort(),
      }
    );
  } finally {
    // Don't leave a listener attached to a long-lived/shared caller signal.
    if (onCallerAbort != null && callerSignal != null) {
      callerSignal.removeEventListener('abort', onCallerAbort);
    }
  }
}

function truncateOutput(value: string, maxChars: number): string {
  if (maxChars <= 0 || value.length <= maxChars) {
    return value;
  }
  const head = Math.max(Math.floor(maxChars / 2), 0);
  const tail = Math.max(maxChars - head, 0);
  return `${value.slice(0, head)}\n...[truncated ${value.length - maxChars} chars]...\n${value.slice(value.length - tail)}`;
}

async function readStream(stream: ReadableStream<Uint8Array>): Promise<Buffer> {
  const reader = stream.getReader();
  const chunks: Uint8Array[] = [];
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk)));
}

async function normalizeReadFileContent(
  result: t.CloudflareSandboxReadFileResult
): Promise<Buffer> {
  if (typeof result === 'string') {
    return Buffer.from(result, 'utf8');
  }
  if (Buffer.isBuffer(result)) {
    return result;
  }
  if (result instanceof Uint8Array) {
    return Buffer.from(result);
  }
  const content = result.content;
  if (typeof content === 'string') {
    if (result.encoding === 'base64') {
      return Buffer.from(content, 'base64');
    }
    return Buffer.from(content, 'utf8');
  }
  if (Buffer.isBuffer(content)) {
    return content;
  }
  if (content instanceof Uint8Array) {
    return Buffer.from(content);
  }
  return readStream(content);
}

function bytesToStream(bytes: Uint8Array): ReadableStream<Uint8Array> {
  return new ReadableStream<Uint8Array>({
    start(controller): void {
      controller.enqueue(bytes);
      controller.close();
    },
  });
}

function normalizeWriteFileContent(content: string | Buffer | Uint8Array): {
  content: string | ReadableStream<Uint8Array>;
  options?: { encoding?: string };
} {
  if (typeof content === 'string') {
    return { content, options: { encoding: 'utf8' } };
  }
  return { content: bytesToStream(content) };
}

function createStats(info: {
  size?: number;
  type?: t.CloudflareSandboxFileInfo['type'];
}): Stats {
  const type = info.type ?? 'file';
  const now = new Date();
  return {
    size: info.size ?? 0,
    isFile: () => type === 'file',
    isDirectory: () => type === 'directory',
    isSymbolicLink: () => type === 'symlink',
    isBlockDevice: () => false,
    isCharacterDevice: () => false,
    isFIFO: () => false,
    isSocket: () => false,
    dev: 0,
    ino: 0,
    mode: 0,
    nlink: 1,
    uid: 0,
    gid: 0,
    rdev: 0,
    blksize: 0,
    blocks: 0,
    atimeMs: now.getTime(),
    mtimeMs: now.getTime(),
    ctimeMs: now.getTime(),
    birthtimeMs: now.getTime(),
    atime: now,
    mtime: now,
    ctime: now,
    birthtime: now,
  } as Stats;
}

function normalizeFileList(
  result: t.CloudflareSandboxListFilesResult
): t.CloudflareSandboxFileInfo[] {
  return Array.isArray(result) ? result : result.files;
}

function entryNameFor(
  info: t.CloudflareSandboxFileInfo,
  parentPath: string
): string {
  if (info.name !== '') {
    return info.name.includes('/') ? path.basename(info.name) : info.name;
  }
  if (info.absolutePath != null && info.absolutePath !== '') {
    return path.basename(info.absolutePath);
  }
  if (info.relativePath != null && info.relativePath !== '') {
    return path.basename(info.relativePath);
  }
  return path.basename(parentPath);
}

function entryAbsolutePath(
  info: t.CloudflareSandboxFileInfo,
  parentPath: string
): string {
  if (info.absolutePath != null && info.absolutePath !== '') {
    return path.normalize(info.absolutePath);
  }
  if (info.relativePath != null && info.relativePath !== '') {
    return path.resolve(parentPath, info.relativePath);
  }
  return path.resolve(parentPath, info.name);
}

function createDirent(info: t.CloudflareSandboxFileInfo): ReaddirEntry {
  return {
    name: entryNameFor(info, ''),
    isFile: () => (info.type ?? 'file') === 'file',
    isDirectory: () => info.type === 'directory',
    isSymbolicLink: () => info.type === 'symlink',
  };
}

async function findChildInfo(
  sandbox: t.CloudflareSandboxRuntime,
  filePath: string,
  timeoutMs: number
): Promise<t.CloudflareSandboxFileInfo | undefined> {
  const parent = path.dirname(filePath);
  const basename = path.basename(filePath);
  const entries = normalizeFileList(
    await withClientTimeout(
      sandbox.listFiles(parent, { includeHidden: true }),
      timeoutMs,
      'cloudflare sandbox listFiles'
    )
  );
  return entries.find((entry) => {
    const absolute = entryAbsolutePath(entry, parent);
    return absolute === filePath || entryNameFor(entry, parent) === basename;
  });
}

export function createCloudflareWorkspaceFS(
  config: t.CloudflareSandboxExecutionConfig
): WorkspaceFS {
  const workspaceRoot = getCloudflareWorkspaceRoot(config);
  // Native-DO file-IO RPCs have the SAME stall hazard as exec() (PR #252): no
  // `signal`, no reliably-enforced timeout, so a cold/unresponsive container
  // hangs the host await until the run-level abort — burning the whole budget on
  // one read (observed: a `read_file` that stalled ~552s before the wall-clock
  // budget killed it). Bound every native FS RPC with the same client-side
  // backstop the exec sites use.
  const fsTimeoutMs = clientFsTimeoutMs(config.timeoutMs ?? DEFAULT_TIMEOUT_MS);
  const bound = <T>(op: Promise<T>, label: string): Promise<T> =>
    withClientTimeout(op, fsTimeoutMs, `cloudflare sandbox ${label}`);

  const fs: WorkspaceFS = {
    readFile: (async (filePath: string, encoding?: 'utf8') => {
      const sandbox = await resolveCloudflareSandbox(config);
      const resolved = toSandboxPath(filePath, workspaceRoot);
      // Wrap the stream drain (normalizeReadFileContent) inside the backstop too:
      // a sandbox.readFile that resolves to a { content: ReadableStream } can
      // still stall mid-drain after the RPC promise settled.
      const buffer = await bound(
        (async (): Promise<Buffer> =>
          normalizeReadFileContent(
            await sandbox.readFile(resolved, encoding ? { encoding } : undefined)
          ))(),
        'readFile'
      );
      return encoding != null ? buffer.toString(encoding) : buffer;
    }) as WorkspaceFS['readFile'],
    writeFile: async (
      filePath: string,
      content: string | Buffer,
      _options?: WriteFileOptions
    ) => {
      const sandbox = await resolveCloudflareSandbox(config);
      const resolved = toSandboxPath(filePath, workspaceRoot);
      const normalized = normalizeWriteFileContent(content);
      await bound(
        sandbox.writeFile(resolved, normalized.content, normalized.options),
        'writeFile'
      );
    },
    stat: async (filePath: string) => {
      const sandbox = await resolveCloudflareSandbox(config);
      const resolved = toSandboxPath(filePath, workspaceRoot);
      if (resolved === workspaceRoot) {
        const entries = normalizeFileList(
          await bound(
            sandbox.listFiles(resolved, { includeHidden: true }),
            'listFiles'
          )
        );
        return createStats({ size: entries.length, type: 'directory' });
      }
      const info = await findChildInfo(sandbox, resolved, fsTimeoutMs);
      if (info != null) {
        return createStats({ size: info.size, type: info.type });
      }
      try {
        const entries = normalizeFileList(
          await bound(
            sandbox.listFiles(resolved, { includeHidden: true }),
            'listFiles'
          )
        );
        return createStats({ size: entries.length, type: 'directory' });
      } catch (error) {
        // A directory-probe timeout is a stalled container, not "not a directory".
        // Don't fall through to the readFile branch — that would wait through a
        // SECOND full backstop (~2x the timeout) before surfacing.
        if (isWorkspaceClientTimeoutError(error)) {
          throw error;
        }
        const buffer = await bound(
          (async (): Promise<Buffer> =>
            normalizeReadFileContent(await sandbox.readFile(resolved)))(),
          'readFile'
        );
        return createStats({ size: buffer.length, type: 'file' });
      }
    },
    readdir: (async (filePath: string, options?: { withFileTypes: true }) => {
      const sandbox = await resolveCloudflareSandbox(config);
      const resolved = toSandboxPath(filePath, workspaceRoot);
      const entries = normalizeFileList(
        await bound(
          sandbox.listFiles(resolved, { includeHidden: true }),
          'listFiles'
        )
      );
      if (options?.withFileTypes === true) {
        return entries.map(createDirent);
      }
      return entries.map((entry) => entryNameFor(entry, resolved));
    }) as WorkspaceFS['readdir'],
    mkdir: async (filePath: string, options?: MakeDirectoryOptions) => {
      const sandbox = await resolveCloudflareSandbox(config);
      await bound(
        sandbox.mkdir(toSandboxPath(filePath, workspaceRoot), {
          recursive: options?.recursive,
        }),
        'mkdir'
      );
    },
    realpath: async (filePath: string) =>
      toSandboxPath(filePath, workspaceRoot),
    unlink: async (filePath: string) => {
      const sandbox = await resolveCloudflareSandbox(config);
      await bound(
        sandbox.deleteFile(toSandboxPath(filePath, workspaceRoot)),
        'deleteFile'
      );
    },
    open: async (filePath: string, _flags: 'r') => {
      const sandbox = await resolveCloudflareSandbox(config);
      const resolved = toSandboxPath(filePath, workspaceRoot);
      const buffer = await bound(
        (async (): Promise<Buffer> =>
          normalizeReadFileContent(await sandbox.readFile(resolved)))(),
        'readFile'
      );
      return {
        read: async (
          target: Buffer,
          offset: number,
          length: number,
          position: number
        ) => {
          const start = Math.max(position, 0);
          const slice = buffer.subarray(start, start + length);
          slice.copy(target, offset);
          return { bytesRead: slice.length, buffer: target };
        },
        close: async () => undefined,
      } as unknown as FileHandle;
    },
  };

  return fs;
}

function createCloudflareSpawn(
  config: t.CloudflareSandboxExecutionConfig
): t.LocalSpawn {
  return (command, args, options) => {
    const stdout = new PassThrough();
    const stderr = new PassThrough();
    const child = new EventEmitter() as ChildProcessWithoutNullStreams;
    const abortController = new AbortController();
    const state = { closed: false };
    /** Read through a function so concurrent `closeOnce` mutation (via
     * `kill()`/abort during an `await`) isn't statically narrowed away. */
    const isClosed = (): boolean => state.closed;
    const closeOnce = (
      exitCode: number | null,
      signal: NodeJS.Signals | null
    ): void => {
      if (state.closed) {
        return;
      }
      state.closed = true;
      stdout.end();
      stderr.end();
      Object.assign(child, {
        exitCode,
        signalCode: signal,
      });
      child.emit('close', exitCode, signal);
    };
    Object.assign(child, {
      stdout,
      stderr,
      stdin: new PassThrough(),
      stdio: [null, stdout, stderr],
      killed: false,
      exitCode: null,
      signalCode: null,
      pid: undefined,
      kill: (signal: NodeJS.Signals = 'SIGTERM') => {
        Object.assign(child, { killed: true, signalCode: signal });
        abortController.abort();
        closeOnce(null, signal);
        return true;
      },
    });

    void (async (): Promise<void> => {
      const ctx = await getRuntimeContext(config);
      const rendered = [command, ...args].map(quote).join(' ');
      const spawnTimeoutMs = (
        options as {
          [LOCAL_SPAWN_TIMEOUT_MS]?: number;
        }
      )[LOCAL_SPAWN_TIMEOUT_MS];
      const timeoutMs =
        typeof spawnTimeoutMs === 'number' && Number.isFinite(spawnTimeoutMs)
          ? spawnTimeoutMs
          : ctx.timeoutMs;
      const timedCommand = withInSandboxTimeout(rendered, timeoutMs);
      const cwd =
        options.cwd == null ? ctx.workspaceRoot : options.cwd.toString();
      if (isClosed()) {
        return;
      }
      const execOptions: t.CloudflareSandboxExecOptions = {
        cwd,
        env: ctx.env,
        timeout: outerTimeoutMs(timeoutMs),
      };
      if (ctx.sandbox.supportsExecSignal === true) {
        execOptions.signal = abortController.signal;
      }
      try {
        const result = await withClientTimeout(
          ctx.sandbox.exec(timedCommand, execOptions),
          clientExecTimeoutMs(timeoutMs),
          'cloudflare sandbox exec',
          // spawnLocalProcess's own timer already resolves the child, so this
          // backstop may safely detach; abort the (signal-aware) exec on timeout.
          { unref: true, onTimeout: () => abortController.abort() }
        );
        if (isClosed()) {
          return;
        }
        if (result.stdout) stdout.write(result.stdout);
        if (result.stderr) stderr.write(result.stderr);
        closeOnce(result.exitCode, null);
      } catch (error) {
        if (isClosed()) {
          return;
        }
        stderr.write((error as Error).message);
        closeOnce(1, null);
      }
    })();

    return child;
  };
}

/**
 * Returns one stable filesystem/process world for a Cloudflare configuration.
 * Probe caches key on the spawn identity, so retaining it avoids repeating
 * remote capability checks whenever an agent binding rebuilds its tools.
 */
export function createCloudflareExecutionWorld(
  config: t.CloudflareSandboxExecutionConfig
): t.ExecutionWorld {
  const workspaceRoot = getCloudflareWorkspaceRoot(config);
  const timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const cached = executionWorldCache.get(config);
  if (
    cached?.workspaceRoot === workspaceRoot &&
    Object.is(cached.timeoutMs, timeoutMs) &&
    cached.sandbox === config.sandbox
  ) {
    return cached.world;
  }
  const fs = Object.freeze(createCloudflareWorkspaceFS(config));
  const world = Object.freeze({
    spawn: createCloudflareSpawn(config),
    fs,
    sandboxed: true,
  });
  executionWorldCache.set(config, {
    world,
    workspaceRoot,
    timeoutMs,
    sandbox: config.sandbox,
  });
  return world;
}

export function createCloudflareLocalExecutionConfig(
  config: t.CloudflareSandboxExecutionConfig
): t.LocalExecutionConfig {
  const workspaceRoot = getCloudflareWorkspaceRoot(config);
  return {
    cwd: workspaceRoot,
    workspace: { root: workspaceRoot },
    exec: createCloudflareExecutionWorld(config),
    shell: config.shell ?? 'bash',
    timeoutMs: config.timeoutMs,
    maxOutputChars: config.maxOutputChars,
    env: config.env,
    includeCodingTools: config.includeCodingTools,
    compileCheck: config.compileCheck,
    readOnly: config.readOnly,
    allowDangerousCommands: config.allowDangerousCommands,
    bashAst: config.bashAst,
    fileCheckpointing: config.fileCheckpointing,
    maxReadBytes: config.maxReadBytes,
    attachReadAttachments: config.attachReadAttachments,
    maxAttachmentBytes: config.maxAttachmentBytes,
    postEditSyntaxCheck: config.postEditSyntaxCheck,
  };
}

export async function validateCloudflareBashCommand(
  command: string,
  args: readonly string[],
  config: t.CloudflareSandboxExecutionConfig
): Promise<void> {
  const localConfig = createCloudflareLocalExecutionConfig(config);
  const validation = await validateBashCommand(command, localConfig);
  if (!validation.valid) {
    throw new Error(validation.errors.join('\n'));
  }

  if (
    args.length > 0 &&
    config.allowDangerousCommands !== true &&
    DESTRUCTIVE_OP_IN_COMMAND_RE.test(command)
  ) {
    const offending = args.find((arg) => PROTECTED_TARGET_ARG_RE.test(arg));
    if (offending !== undefined) {
      throw new Error(
        `Command matches a destructive command pattern (protected target "${offending}" passed via positional arg).`
      );
    }
  }
}

export async function executeCloudflareBash(
  command: string,
  config: t.CloudflareSandboxExecutionConfig,
  args: readonly string[] = []
): Promise<SpawnResult> {
  await validateCloudflareBashCommand(command, args, config);
  const ctx = await getRuntimeContext(config);
  const shellCommand =
    args.length > 0
      ? `${ctx.shell} -lc ${quote(command)} -- ${args.map(quote).join(' ')}`
      : `${ctx.shell} -lc ${quote(command)}`;
  const result = await execWithClientTimeout(
    ctx.sandbox,
    withInSandboxTimeout(shellCommand, ctx.timeoutMs),
    {
      cwd: ctx.workspaceRoot,
      env: ctx.env,
      timeout: outerTimeoutMs(ctx.timeoutMs),
    },
    clientExecTimeoutMs(ctx.timeoutMs),
    'cloudflare sandbox bash exec'
  );
  return {
    stdout: truncateOutput(result.stdout, ctx.maxOutputChars),
    stderr: truncateOutput(result.stderr, ctx.maxOutputChars),
    exitCode: result.exitCode,
    timedOut: isInSandboxTimeoutExit(result.exitCode),
  };
}

function runtimeForCode(
  lang: string,
  tempDir: string,
  code: string,
  args: string[] = [],
  shell = 'bash'
): RuntimeCommand {
  const fileFor = (name: string): string => path.join(tempDir, name);
  const argText = args.map(quote).join(' ');
  switch (lang) {
  case 'py':
  case 'python':
    return {
      fileName: 'main.py',
      source: code,
      command: `python3 ${quote(fileFor('main.py'))} ${argText}`,
    };
  case 'js':
  case 'javascript':
    return {
      fileName: 'main.js',
      source: code,
      command: `node ${quote(fileFor('main.js'))} ${argText}`,
    };
  case 'ts':
  case 'typescript':
    return {
      fileName: 'main.ts',
      source: code,
      command: `npx --no-install tsx ${quote(fileFor('main.ts'))} ${argText}`,
    };
  case 'php':
    return {
      fileName: 'main.php',
      source: code,
      command: `php ${quote(fileFor('main.php'))} ${argText}`,
    };
  case 'go':
    return {
      fileName: 'main.go',
      source: code,
      command: `go run ${quote(fileFor('main.go'))} ${argText}`,
    };
  case 'rs':
    return {
      fileName: 'main.rs',
      source: code,
      command: `${shell} -lc ${quote(
        `rustc ${quote(fileFor('main.rs'))} -o ${quote(fileFor('main-rs'))} && ${quote(fileFor('main-rs'))} ${argText}`
      )}`,
    };
  case 'c':
    return {
      fileName: 'main.c',
      source: code,
      command: `${shell} -lc ${quote(
        `cc ${quote(fileFor('main.c'))} -o ${quote(fileFor('main-c'))} && ${quote(fileFor('main-c'))} ${argText}`
      )}`,
    };
  case 'cpp':
    return {
      fileName: 'main.cpp',
      source: code,
      command: `${shell} -lc ${quote(
        `c++ ${quote(fileFor('main.cpp'))} -o ${quote(fileFor('main-cpp'))} && ${quote(fileFor('main-cpp'))} ${argText}`
      )}`,
    };
  case 'java':
    return {
      fileName: 'Main.java',
      source: code,
      command: `${shell} -lc ${quote(
        `javac ${quote(fileFor('Main.java'))} && java -cp ${quote(tempDir)} Main ${argText}`
      )}`,
    };
  case 'r':
    return {
      fileName: 'main.R',
      source: code,
      command: `Rscript ${quote(fileFor('main.R'))} ${argText}`,
    };
  case 'd':
    return {
      fileName: 'main.d',
      source: code,
      command: `${shell} -lc ${quote(
        `dmd ${quote(fileFor('main.d'))} -of=${quote(fileFor('main-d'))} && ${quote(fileFor('main-d'))} ${argText}`
      )}`,
    };
  case 'f90':
    return {
      fileName: 'main.f90',
      source: code,
      command: `${shell} -lc ${quote(
        `gfortran ${quote(fileFor('main.f90'))} -o ${quote(fileFor('main-f90'))} && ${quote(fileFor('main-f90'))} ${argText}`
      )}`,
    };
  case 'bash':
  case 'sh':
    return {
      fileName: 'main.sh',
      source: code,
      command: `${shell} -lc ${quote(code)} -- ${argText}`,
    };
  default:
    throw new Error(`Unsupported Cloudflare sandbox runtime: ${lang}`);
  }
}

export async function executeCloudflareCode(
  input: { lang: string; code: string; args?: string[] },
  config: t.CloudflareSandboxExecutionConfig
): Promise<SpawnResult> {
  if (input.lang === 'bash' || input.lang === 'sh') {
    return executeCloudflareBash(input.code, config, input.args ?? []);
  }
  const ctx = await getRuntimeContext(config);
  const id = globalThis.crypto.randomUUID();
  const tempDir = path.join(ctx.workspaceRoot, '.lc-exec', id);
  const runtime = runtimeForCode(
    input.lang,
    tempDir,
    input.code,
    input.args,
    ctx.shell
  );
  let execSucceeded = false;
  try {
    // Bound the temp-dir setup RPCs (they run BEFORE the bounded exec): a
    // native-DO stall here would hang the host on a single mkdir/writeFile and
    // burn the run budget. Keep them INSIDE the try so the finally cleanup still
    // removes .lc-exec/<uuid> if setup throws — the uncancellable write can land
    // late on a cold container, so an orphaned dir would otherwise accumulate.
    await withClientTimeout(
      ctx.sandbox.mkdir(tempDir, { recursive: true }),
      clientFsTimeoutMs(ctx.timeoutMs),
      'cloudflare sandbox mkdir'
    );
    if (runtime.source != null) {
      await withClientTimeout(
        ctx.sandbox.writeFile(
          path.join(tempDir, runtime.fileName),
          runtime.source,
          { encoding: 'utf8' }
        ),
        clientFsTimeoutMs(ctx.timeoutMs),
        'cloudflare sandbox writeFile'
      );
    }
    const result = await execWithClientTimeout(
      ctx.sandbox,
      withInSandboxTimeout(runtime.command, ctx.timeoutMs),
      {
        cwd: ctx.workspaceRoot,
        env: ctx.env,
        timeout: outerTimeoutMs(ctx.timeoutMs),
      },
      clientExecTimeoutMs(ctx.timeoutMs),
      'cloudflare sandbox code-exec'
    );
    execSucceeded = true;
    return {
      stdout: truncateOutput(result.stdout, ctx.maxOutputChars),
      stderr: truncateOutput(result.stderr, ctx.maxOutputChars),
      exitCode: result.exitCode,
      timedOut: isInSandboxTimeoutExit(result.exitCode),
    };
  } finally {
    // After a normal run, AWAIT cleanup so the temp dir is gone before returning.
    // After a stalled/failed run, detach it (unref'd) so we don't pile a second
    // client timeout onto the caller's latency; cleanup still runs best-effort.
    const detach = !execSucceeded;
    const cleanup = execWithClientTimeout(
      ctx.sandbox,
      `rm -rf ${quote(tempDir)}`,
      {
        cwd: ctx.workspaceRoot,
        env: ctx.env,
        timeout: 10000,
      },
      clientExecTimeoutMs(10000),
      'cloudflare sandbox cleanup',
      { unref: detach }
    ).catch(() => undefined);
    if (!detach) {
      await cleanup;
    }
  }
}

export function formatCloudflareOutput(
  result: SpawnResult,
  cwd: string
): string {
  let formatted = '';
  if (result.stdout !== '') {
    formatted += `stdout:\n${result.stdout}\n`;
  } else {
    formatted += 'stdout: Empty. Ensure you\'re writing output explicitly.\n';
  }
  if (result.stderr !== '') {
    formatted += `stderr:\n${result.stderr}\n`;
  }
  if (result.exitCode != null && result.exitCode !== 0) {
    formatted += `exit_code: ${result.exitCode}\n`;
  }
  if (result.timedOut) {
    formatted += 'timed_out: true\n';
  }
  formatted += `working_directory: ${cwd}`;
  return formatted.trim();
}
